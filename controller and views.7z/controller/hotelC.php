<?php

include ($_SERVER["DOCUMENT_ROOT"] . '/Spot/config.php');
class hotelC
{
    function ajouterHotel(Hotel  $Hotel){
        $sql="INSERT INTO Hotel (nomhotel, etoile, description, id_destination) 
            VALUES (:nomhotel, :etoile, :description, :id_destination)";
        $db = config::getConnexion();
        try{
            $query = $db->prepare($sql);

            $query->execute([
                'nomhotel' => $Hotel->getNomhotel(),
                'etoile' => $Hotel->getEtoile(),
                'description' => $Hotel->getDescription(),
                'id_destination' => $Hotel->getIdDest()
            ]);
        } catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

    function supprimerHotel($id){
        $sql="DELETE FROM Hotel where id= :id";
        $db = config::getConnexion();
        $req=$db->prepare($sql);
        $req->bindValue(':id',$id);
        try{
            $req->execute();
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

    function modifierHotel($id, Hotel $Hotel){
        $sql="UPDATE Hotel SET  nomhotel=:nomhotel,etoile=:etoile,description=:description,id_destination=:id_destination WHERE id=:id";

        $db = config::getConnexion();
        //$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
        try{
            $req=$db->prepare($sql);

            $req->bindValue(':id',$id);
            $req->bindValue(':nomhotel',$Hotel->getNomhotel());
            $req->bindValue(':etoile',$Hotel->getEtoile());
            $req->bindValue(':description',$Hotel->getDescription());
            $req->bindValue(':id_destination',$Hotel->getIdDest());
            $req->execute();
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
            echo " Les datas : " ;

        }

    }
    public function recupererHotel($id){
        $sql="SELECT * FROM `Hotel` where id=".$id;
        $db=Config::getConnexion();
        try{

            return $db->query($sql);
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    public function afficherHotel(){
        $sql="SELECT * FROM `Hotel`";
        $db=Config::getConnexion();
        try{
            return $db->query($sql);
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    function recherchehotel($nom){
        $sql="SElECT * From Hotel where nomhotel like '%$nom%' ";
        $db = config::getConnexion();
        try{
            $liste=$db->query($sql);
            $r=$liste;
            return $r;
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

    function affichernameDest($id){
        $sql="SELECT d.villeto as noom FROM `Hotel` as h INNER JOIN destination as d on h.id_destination=d.id where h.id_destination=$id";
        $db = config::getConnexion();
        try{
            $req = $db->prepare($sql);
            $req->execute();
            foreach ($req as $row):
                {
                    return $row['noom'];
                }
            endforeach;


        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    public function afficherDestination(){
        $sql="SELECT * FROM `Destination`";
        $db=Config::getConnexion();
        try{
            return $db->query($sql);
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
}

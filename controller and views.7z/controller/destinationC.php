<?php

include ($_SERVER["DOCUMENT_ROOT"] . '/Spot/config.php');
class destinationC
{

    function ajouterDestination(Destination  $Destination){
        $sql="INSERT INTO Destination (villeFrom,villeTo) 
            VALUES (:villeFrom, :villeTo)";
        $db = config::getConnexion();
        try{
            $query = $db->prepare($sql);

            $query->execute([
                'villeFrom' => $Destination->getVillefrom(),
                'villeTo' => $Destination->getVilleto()
            ]);
        } catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

    function supprimerDestination($id){
        $sql="DELETE FROM Destination where id= :id";
        $db = config::getConnexion();
        $req=$db->prepare($sql);
        $req->bindValue(':id',$id);
        try{
            $req->execute();
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

    function modifierDestination($id, Destination $Destination){
        $sql="UPDATE Destination SET  villeFrom=:villeFrom,villeTo=:villeTo WHERE id=:id";

        $db = config::getConnexion();
        //$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
        try{
            $req=$db->prepare($sql);

            $req->bindValue(':id',$id);
            $req->bindValue(':villeFrom',$Destination->getVillefrom());
            $req->bindValue(':villeTo',$Destination->getVilleto());

            $req->execute();
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
            echo " Les datas : " ;

        }

    }
    public function recupererDestination($id){
        $sql="SELECT * FROM `Destination` where id=".$id;
        $db=Config::getConnexion();
        try{

            return $db->query($sql);
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    public function afficherDestination(){
        $sql="SELECT * FROM `Destination`";
        $db=Config::getConnexion();
        try{
            return $db->query($sql);
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

}

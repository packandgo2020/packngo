<?php
include ($_SERVER["DOCUMENT_ROOT"] . '/Spot/config.php');

class volsC
{
    function ajouterVols(Vols  $Vols){
        $sql="INSERT INTO Vols (nom_compagnie, nom_aeroport, dateD, dateR,etatVol,id_destination) 
            VALUES (:nom_compagnie, :nom_aeroport, :dateD, :dateR,:etatVol,:id_destination)";
        $db = config::getConnexion();
        try{
            $query = $db->prepare($sql);

            $query->execute([
                'nom_compagnie' => $Vols->getNomCompagnie(),
                'nom_aeroport' => $Vols->getNomAeroport(),
                'dateD' => $Vols->getDateD(),
                'dateR' => $Vols->getDateR(),
                'etatVol' => $Vols->getEtatVol(),
                'id_destination' => $Vols->getIdDest()
            ]);
        } catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

    function supprimerVols($id){
        $sql="DELETE FROM Vols where id= :id";
        $db = config::getConnexion();
        $req=$db->prepare($sql);
        $req->bindValue(':id',$id);
        try{
            $req->execute();
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

    function modifierVols($id, Vols $Vols){
        $sql="UPDATE Vols SET  nom_compagnie=:nom_compagnie, nom_aeroport=:nom_aeroport, dateD=:dateD, dateR=:dateR,etatVol=:etatVol,id_destination=:id_destination WHERE id=:id";

        $db = config::getConnexion();
        //$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
        try{
            $req=$db->prepare($sql);

            $req->bindValue(':id',$id);
            $req->bindValue(':nom_compagnie',$Vols->getNomCompagnie());
            $req->bindValue(':nom_aeroport',$Vols->getNomAeroport());
            $req->bindValue(':dateD',$Vols->getDateD());
            $req->bindValue(':dateR',$Vols->getDateR());
            $req->bindValue(':etatVol',$Vols->getEtatVol());
            $req->bindValue(':id_destination',$Vols->getIdDest());
            $req->execute();
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
            echo " Les datas : " ;

        }

    }
    public function recupererVols($id){
        $sql="SELECT * FROM `Vols` where id=".$id;
        $db=Config::getConnexion();
        try{

            return $db->query($sql);
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    public function afficherVols(){
        $sql="SELECT * FROM `Vols`";
        $db=Config::getConnexion();
        try{
            return $db->query($sql);
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    public function afficherDestination(){
        $sql="SELECT * FROM `Destination`";
        $db=Config::getConnexion();
        try{
            return $db->query($sql);
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    function affichernameDest($id){
        $sql="SELECT d.villeto as noom FROM `Hotel` as h INNER JOIN destination as d on h.id_destination=d.id where h.id_destination=$id";
        $db = config::getConnexion();
        try{
            $req = $db->prepare($sql);
            $req->execute();
            foreach ($req as $row):
                {
                    return $row['noom'];
                }
            endforeach;


        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

}

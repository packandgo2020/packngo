<?PHP
include ($_SERVER["DOCUMENT_ROOT"] . '/Spot/config.php');


    class VoyageC {


        public function recupererDestination(){
            $sql="SELECT * FROM `destination`";
            $db=Config::getConnexion();
            try{
                return $db->query($sql);
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
        }


    function ajouterVoyage(Voyage  $Voyage){
            $sql="INSERT INTO Voyage (user_id, destination, datedepart, dateretour) 
            VALUES (:user_id, :destination, :datedepart, :dateretour)";
            $db = config::getConnexion();
            try{
                $query = $db->prepare($sql);
            
                $query->execute([
                    'user_id' => $Voyage->getLogin(),
                    'destination' => $Voyage->getDestination(),
                    'datedepart' => $Voyage->getDatedepart(),
                    'dateretour' => $Voyage->getDateretour()
                ]);         
            } catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
}

        function supprimerVoyage($id){
            $sql="DELETE FROM Voyage where id= :id";
            $db = config::getConnexion();
            $req=$db->prepare($sql);
            $req->bindValue(':id',$id);
            try{
                $req->execute();
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
        }

        function modifierVoyage($id, Voyage $Voyage){
            $sql="UPDATE Voyage SET  user_id=:user_id,destination=:destination,datedepart=:datedepart,dateretour=:dateretour WHERE id=:id";

            $db = config::getConnexion();
            //$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
            try{
                $req=$db->prepare($sql);

                $req->bindValue(':id',$id);
                $req->bindValue(':user_id',$Voyage->getLogin());
                $req->bindValue(':destination',$Voyage->getDestination());
                $req->bindValue(':datedepart',$Voyage->getDatedepart());
                $req->bindValue(':dateretour',$Voyage->getDateretour());
                $req->execute();
            }
            catch (Exception $e){
                echo " Erreur ! ".$e->getMessage();
                echo " Les datas : " ;

            }

        }
        public function recupererVoyage($id){
            $sql="SELECT * FROM `Voyage` where id=".$id;
            $db=Config::getConnexion();
            try{

                return $db->query($sql);
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
        }
        public function afficherVoyage(){
            $sql="SELECT * FROM `Voyage`";
            $db=Config::getConnexion();
            try{
                return $db->query($sql);
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
        }


    }

?>

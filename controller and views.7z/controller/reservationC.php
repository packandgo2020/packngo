<?php
include ($_SERVER["DOCUMENT_ROOT"] . '/Spot/config.php');

class reservationC
{
    function ajouterReservation(Reservation  $Reservation){
        $sql="INSERT INTO Reservation (numeroR, dateD, dateR, adult,child,id_vol,id_hotel,id_user) 
            VALUES (:numeroR, :dateD, :dateR, :adult,:child,:id_vol,:id_hotel,:id_user)";
        $db = config::getConnexion();
        try{
            $query = $db->prepare($sql);

            $query->execute([
                'numeroR' => $Reservation->getNumeroR(),
                'dateD' => $Reservation->getDateD(),
                'dateR' => $Reservation->getDateR(),
                'adult' => $Reservation->getAdult(),
                'child' => $Reservation->getChild(),
                'id_vol' => $Reservation->getIdVol(),
                'id_hotel' => $Reservation->getIdHotel(),
                'id_user' => $Reservation->getIdUser()
            ]);
        } catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

    function supprimerReservation($id){
        $sql="DELETE FROM Reservation where id= :id";
        $db = config::getConnexion();
        $req=$db->prepare($sql);
        $req->bindValue(':id',$id);
        try{
            $req->execute();
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

    function modifierReservation($id, Reservation $Reservation){
        $sql="UPDATE Reservation SET  numeroR=:numeroR, dateD=:dateD, dateR=:dateR, adult=:adult,child=:child,id_vol=:id_vol,id_hotel=:id_hotel,id_user=:id_user WHERE id=:id";

        $db = config::getConnexion();
        //$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
        try{
            $req=$db->prepare($sql);

            $req->bindValue(':id',$id);
            $req->bindValue(':numeroR',$Reservation->getNumeroR());
            $req->bindValue(':dateD',$Reservation->getDateD());
            $req->bindValue(':dateR',$Reservation->getDateR());
            $req->bindValue(':adult',$Reservation->getAdult());
            $req->bindValue(':child',$Reservation->getChild());
            $req->bindValue(':id_vol',$Reservation->getIdVol());
            $req->bindValue(':id_hotel',$Reservation->getIdHotel());
            $req->bindValue(':id_user',$Reservation->getIdUser());
            $req->execute();
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
            echo " Les datas : " ;

        }

    }
    public function recupererReservation($id){
        $sql="SELECT * FROM `Reservation` where id=".$id;
        $db=Config::getConnexion();
        try{

            return $db->query($sql);
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    public function afficherReservation(){
        $sql="SELECT * FROM `Reservation`";
        $db=Config::getConnexion();
        try{
            return $db->query($sql);
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    public function afficherDestination(){
        $sql="SELECT * FROM `Destination`";
        $db=Config::getConnexion();
        try{
            return $db->query($sql);
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    function affichernameDest($id){
        $sql="SELECT d.villeto as noom FROM `Hotel` as h INNER JOIN destination as d on h.id_destination=d.id where h.id_destination=$id";
        $db = config::getConnexion();
        try{
            $req = $db->prepare($sql);
            $req->execute();
            foreach ($req as $row):
                {
                    return $row['noom'];
                }
            endforeach;


        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

    public function searchhotel($to,$hot){
        $sql="SELECT h.* FROM hotel as h inner join destination as d on h.id_destination=d.id where d.villeto='".$to."' and h.nomhotel='".$hot."' ";
        $db=Config::getConnexion();
        try{
            return $db->query($sql);
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    public function searchvol($from,$to,$hot){
        $sql="SELECT v.* FROM vols as v inner join destination as d on v.id_destination=d.id where d.villefrom='".$from."' and d.villeto='".$to."' and v.nom_compagnie='".$hot."' ";
        $db=Config::getConnexion();
        try{
            return $db->query($sql);
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

    public function searchreservation($num,$name){
        $sql="SELECT r.* FROM Reservation as r inner join utilisateur as u on r.id_user=u.id where r.numeroR='".$num."' and u.nom='".$name."' ";
        $db=Config::getConnexion();
        try{
            return $db->query($sql);
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

}

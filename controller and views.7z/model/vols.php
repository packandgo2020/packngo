<?php


class vols
{
    private $id;
    private $nom_compagnie;
    private $nom_aeroport;
    private $dateD;
    private $dateR;
    private $etatVol;
    private $idDest;

    /**
     * vols constructor.
     * @param $nom_compagnie
     * @param $nom_aeroport
     * @param $dateD
     * @param $dateR
     * @param $etatVol
     * @param $idDest
     */
    public function __construct($nom_compagnie, $nom_aeroport, $dateD, $dateR, $etatVol, $idDest)
    {
        $this->nom_compagnie = $nom_compagnie;
        $this->nom_aeroport = $nom_aeroport;
        $this->dateD = $dateD;
        $this->dateR = $dateR;
        $this->etatVol = $etatVol;
        $this->idDest = $idDest;
    }


    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getNomCompagnie()
    {
        return $this->nom_compagnie;
    }

    /**
     * @param mixed $nom_compagnie
     */
    public function setNomCompagnie($nom_compagnie)
    {
        $this->nom_compagnie = $nom_compagnie;
    }

    /**
     * @return mixed
     */
    public function getNomAeroport()
    {
        return $this->nom_aeroport;
    }

    /**
     * @param mixed $nom_aeroport
     */
    public function setNomAeroport($nom_aeroport)
    {
        $this->nom_aeroport = $nom_aeroport;
    }

    /**
     * @return mixed
     */
    public function getDateD()
    {
        return $this->dateD;
    }

    /**
     * @param mixed $dateD
     */
    public function setDateD($dateD)
    {
        $this->dateD = $dateD;
    }

    /**
     * @return mixed
     */
    public function getDateR()
    {
        return $this->dateR;
    }

    /**
     * @param mixed $dateR
     */
    public function setDateR($dateR)
    {
        $this->dateR = $dateR;
    }

    /**
     * @return mixed
     */
    public function getEtatVol()
    {
        return $this->etatVol;
    }

    /**
     * @param mixed $etatVol
     */
    public function setEtatVol($etatVol)
    {
        $this->etatVol = $etatVol;
    }

    /**
     * @return mixed
     */
    public function getIdDest()
    {
        return $this->idDest;
    }

    /**
     * @param mixed $idDest
     */
    public function setIdDest($idDest)
    {
        $this->idDest = $idDest;
    }



}

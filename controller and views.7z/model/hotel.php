<?php


class hotel
{
private $id;
private $nomhotel;
private $etoile;
private $description;
private $idDest;

    /**
     * hotel constructor.
     * @param $nomhotel
     * @param $etoile
     * @param $description
     * @param $idDest
     */
    public function __construct($nomhotel, $etoile, $description, $idDest)
    {
        $this->nomhotel = $nomhotel;
        $this->etoile = $etoile;
        $this->description = $description;
        $this->idDest = $idDest;
    }


    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getNomhotel()
    {
        return $this->nomhotel;
    }

    /**
     * @param mixed $nomhotel
     */
    public function setNomhotel($nomhotel)
    {
        $this->nomhotel = $nomhotel;
    }

    /**
     * @return mixed
     */
    public function getEtoile()
    {
        return $this->etoile;
    }

    /**
     * @param mixed $etoile
     */
    public function setEtoile($etoile)
    {
        $this->etoile = $etoile;
    }

    /**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param mixed $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    /**
     * @return mixed
     */
    public function getIdDest()
    {
        return $this->idDest;
    }

    /**
     * @param mixed $idDest
     */
    public function setIdDest($idDest)
    {
        $this->idDest = $idDest;
    }

}

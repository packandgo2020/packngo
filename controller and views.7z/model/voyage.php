<?php
class Voyage {
    private $id;
    private $login;
    private $destination;
    private $datedepart;
    private $dateretour;

    /**
     * Voyage constructor.
     * @param $id
     * @param $login
     * @param $destination
     * @param $datedepart
     * @param $dateretour
     */
    public function __construct( $login, $destination, $datedepart, $dateretour)
    {
        $this->login = $login;
        $this->destination = $destination;
        $this->datedepart = $datedepart;
        $this->dateretour = $dateretour;
    }


    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getLogin()
    {
        return $this->login;
    }

    /**
     * @param mixed $login
     */
    public function setLogin($login)
    {
        $this->login = $login;
    }

    /**
     * @return mixed
     */
    public function getDestination()
    {
        return $this->destination;
    }

    /**
     * @param mixed $destination
     */
    public function setDestination($destination)
    {
        $this->destination = $destination;
    }

    /**
     * @return mixed
     */
    public function getDatedepart()
    {
        return $this->datedepart;
    }

    /**
     * @param mixed $datedepart
     */
    public function setDatedepart($datedepart)
    {
        $this->datedepart = $datedepart;
    }

    /**
     * @return mixed
     */
    public function getDateretour()
    {
        return $this->dateretour;
    }

    /**
     * @param mixed $dateretour
     */
    public function setDateretour($dateretour)
    {
        $this->dateretour = $dateretour;
    }


  
}
?>

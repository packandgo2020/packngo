<?php


class reservation
{
    private $id;
    private $numeroR;
    private $dateD;
    private $dateR;
    private $adult;
    private $child;
    private $id_vol;
    private $id_hotel;
    private $id_user;

    /**
     * reservation constructor.
     * @param $numeroR
     * @param $dateD
     * @param $dateR
     * @param $adult
     * @param $child
     * @param $id_vol
     * @param $id_hotel
     * @param $id_user
     */
    public function __construct($numeroR, $dateD, $dateR, $adult, $child, $id_vol, $id_hotel, $id_user)
    {
        $this->numeroR = $numeroR;
        $this->dateD = $dateD;
        $this->dateR = $dateR;
        $this->adult = $adult;
        $this->child = $child;
        $this->id_vol = $id_vol;
        $this->id_hotel = $id_hotel;
        $this->id_user = $id_user;
    }


    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getNumeroR()
    {
        return $this->numeroR;
    }

    /**
     * @param mixed $numeroR
     */
    public function setNumeroR($numeroR)
    {
        $this->numeroR = $numeroR;
    }

    /**
     * @return mixed
     */
    public function getDateD()
    {
        return $this->dateD;
    }

    /**
     * @param mixed $dateD
     */
    public function setDateD($dateD)
    {
        $this->dateD = $dateD;
    }

    /**
     * @return mixed
     */
    public function getDateR()
    {
        return $this->dateR;
    }

    /**
     * @param mixed $dateR
     */
    public function setDateR($dateR)
    {
        $this->dateR = $dateR;
    }

    /**
     * @return mixed
     */
    public function getAdult()
    {
        return $this->adult;
    }

    /**
     * @param mixed $adult
     */
    public function setAdult($adult)
    {
        $this->adult = $adult;
    }

    /**
     * @return mixed
     */
    public function getChild()
    {
        return $this->child;
    }

    /**
     * @param mixed $child
     */
    public function setChild($child)
    {
        $this->child = $child;
    }

    /**
     * @return mixed
     */
    public function getIdVol()
    {
        return $this->id_vol;
    }

    /**
     * @param mixed $id_vol
     */
    public function setIdVol($id_vol)
    {
        $this->id_vol = $id_vol;
    }

    /**
     * @return mixed
     */
    public function getIdHotel()
    {
        return $this->id_hotel;
    }

    /**
     * @param mixed $id_hotel
     */
    public function setIdHotel($id_hotel)
    {
        $this->id_hotel = $id_hotel;
    }

    /**
     * @return mixed
     */
    public function getIdUser()
    {
        return $this->id_user;
    }

    /**
     * @param mixed $id_user
     */
    public function setIdUser($id_user)
    {
        $this->id_user = $id_user;
    }



}

<?php


class destination
{
    private  $id;
    private  $villefrom;
    private  $villeto;

    /**
     * destination constructor.
     * @param $villefrom
     * @param $villeto
     */
    public function __construct($villefrom, $villeto)
    {
        $this->villefrom = $villefrom;
        $this->villeto = $villeto;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getVillefrom()
    {
        return $this->villefrom;
    }

    /**
     * @param mixed $villefrom
     */
    public function setVillefrom($villefrom)
    {
        $this->villefrom = $villefrom;
    }

    /**
     * @return mixed
     */
    public function getVilleto()
    {
        return $this->villeto;
    }

    /**
     * @param mixed $villeto
     */
    public function setVilleto($villeto)
    {
        $this->villeto = $villeto;
    }



}
